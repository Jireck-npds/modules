<?php 
/************************************************************************/
/* DUNE by NPDS                                                         */
/* ===========================                                          */
/*                                                                      */
/* NPDS Copyright (c) 2002-2008 by Philippe Brunier                     */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/*                                                                      */
/* Module video_yt                                                      */
/* video_yt_set 2007 by jpb                                             */
/*                                                                      */
/* version 2.0 12/09                                                    */
/************************************************************************/
// param&#xE8;tres Youtube 
$dev_id = ""; // obtenez votre DEV_ID at http://www.youtube.com/signup?next=my_profile_dev 
$dev_key = ""; // clef necessaire uniquement pour les futures opérations d'ecriture 
$account = "infocapagde";// YouTube Username 
// mise en forme 
$rep_account = "";// youtube name 
$incrementby = 7;// nombre de vid&#xE9;os par page dans vid&#xE9;oth&#xE8;que 
$search_incrementby = "10";// nombre de vid&#xE9;os dans la recherche 
$bg_yt_search = "666666";// couleur du background de la zone d'affichage des recherches
$video_width = "320"; //largeur de l'objet 
$video_height = "265"; //hauteur de l'objet 
$bloc_width = "135"; //largeur de l'objet dans le bloc
$bloc_height = "135"; //hauteur de l'objet dans le bloc 
$class_sty_1 = "titrgkc"; //titre de la page 
$class_sty_2 = "yt_soustitre"; //sous-titre de la page 
$class_sty_3 = ""; //commentaire 
?>