<?php
/************************************************************************/
/* DUNE by NPDS                                                         */
/* ===========================                                          */
/*                                                                      */
/* NPDS Copyright (c) 2002-2008 by Philippe Brunier                     */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* Module video_yt                                                      */
/* pages.php file 2007 by jpb                                           */
/*                                                                      */
/* version 2.0 12/09                                                    */
/************************************************************************/

$PAGES['modules.php?ModPath='.$ModPath.'&ModStart=video_yt*'][title]="[french]Vid&#xE9;os[/french][english]Videos[/english][chinese]&#x5F55;&#x5F71;[/chinese]+";
$PAGES['modules.php?ModPath='.$ModPath.'&ModStart=video_yt*'][run]="yes";
$PAGES['modules.php?ModPath='.$ModPath.'&ModStart=video_yt*'][css]="yt_style.css+";
$PAGES['modules.php?ModPath='.$ModPath.'&ModStart=video_yt*'][blocs]="0";
$PAGES['modules.php?ModPath='.$ModPath.'&ModStart=video_yt*'][js]=array($nuke_url.'/modules/video_yt/include/video_yt.js');
$PAGES['modules.php?ModPath='.$ModPath.'&ModStart=video_yt*'][TinyMce]=0;
?>