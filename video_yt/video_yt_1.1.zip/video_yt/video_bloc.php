<?php
/************************************************************************/
/* NPDS V : Net Portal Dynamic System .                                 */
/* ===========================                                          */
/*                                                                      */
/* Original Copyright (c) 2001 by Francisco Burzi (fburzi@ncc.org.ve)   */
/* http://phpnuke.org                                                   */
/*                                                                      */
/* This version name NPDS Copyright (c) 2001-2007 by Philippe Brunier   */
/*                                                                      */
/*                                                                      */
/* video_yt bloc file 2007 by jpb                                       */
/*                                                                      */
/************************************************************************/

$ModPath="video_yt";
include ("modules/$ModPath/video_yt_conf.php");

//r�cup�ration fichier xml de youtube
$stream=file_get_contents("http://www.youtube.com/api2_rest?method=youtube.videos.list_by_user&dev_id=$dev_id&user=$account");
preg_match_all('#<title>(.*?)</title>#',$stream,$regs);
$array_title=$regs[1];
//mise en tableau
preg_match_all('#<id>(.*?)</id>#',$stream,$regs); ;
$array_id=$regs[1];   
srand ((double) microtime() * 10000000); // for old php  < 4.2.0...
$vid_ran = array_rand ($array_id, 1);//the second parameter can be change 1 ou +
$content="";
$nb=0;
if (is_array($vid_ran)) {$nb=count($vid_ran);} else {$nb=1;};
for($i=0; $i<$nb; $i++)
{
if (is_array($vid_ran)) {$id_ran=$vid_ran[$i];} else {$id_ran=$vid_ran;};
$content.="$array_title[$id_ran]<br/ ><object width=\"$bloc_width\" height=\"$bloc_height\" title=\"[french]Cliquez sur la fl&#xE8;che centrale pour voir la vid&#xE9;o dans le bloc. click anywhere to watch the video on Youtube website.[/french][english]Click on the central arrow to watch the video in the bloc.  else click anywhere to watch the video on Youtube website.[/english][chinese][/chinese]\"><embed src=\"http://www.youtube.com/v/$array_id[$id_ran]\" type=\"application/x-shockwave-flash\" wmode=\"transparent\" width=\"$bloc_width\" height=\"$bloc_height\"></embed></object><br /><a href=\"modules.php?ModPath=video_yt&ModStart=video_yt&video_id=$array_id[$id_ran]\">[french]Voir[/french][english]Watch[/english][chinese]&#x89C2;&#x770B;&#x8FD9;&#x5F55;&#x5F71;[/chinese]</a> | <a href=\"modules.php?ModPath=video_yt&ModStart=video_yt\">[french]Vid&#xE9;oth&#xE8;que[/french][english]Videos[/english][chinese]&#x5F55;&#x5F71;[/chinese]</a> | <a href=\"http://gdata.youtube.com/feeds/api/users/$account/uploads\" target=\"blank\"><img src =\"modules/$ModPath/images/standard_rss.png\" border=\"0\">
</a><hr />";
$content=aff_langue($content);
}
?>