<?php
/************************************************************************/
/* NPDS V : Net Portal Dynamic System .                                 */
/* ===========================                                          */
/*                                                                      */
/* Original Copyright (c) 2001 by Francisco Burzi (fburzi@ncc.org.ve)   */
/* http://phpnuke.org                                                   */
/*                                                                      */
/* This version name NPDS Copyright (c) 2001-2007 by Philippe Brunier   */
/*                                                                      */
/*                                                                      */
/* video_yt file 2007 by Jean Pierre Barbary                            */
/* version 1.1 02/08                                                    */
/************************************************************************/

if(!IsSet($mainfile)) { include ("mainfile.php"); }
global $pdsts , $language , $locale;
$pdst=1;

   if (strstr($ModPath,"..") || strstr($ModStart,"..") || stristr($ModPath, "script") || stristr($ModPath, "cookie") || stristr($ModPath, "iframe") || stristr($ModPath, "applet") || stristr($ModPath, "object") || stristr($ModPath, "meta") || stristr($ModStart, "script") || stristr($ModStart, "cookie") || stristr($ModStart, "iframe") || stristr($ModStart, "applet") || stristr($ModStart, "object") || stristr($ModStart, "meta")) {die();}

include ('header.php');
include ("modules/$ModPath/video_yt_conf.php");
include ("modules/$ModPath/lang/video_yt.lang-$language.php");
$pat = "#".$account."#";

if(isset($_GET['video_id'])) 
{
$incrementby = 1;
$video_id = $_GET['video_id'];
$stream=file_get_contents("http://www.youtube.com/api2_rest?method=youtube.videos.get_details&dev_id=$dev_id&video_id=$video_id");
}
else
{
$stream=file_get_contents("http://www.youtube.com/api2_rest?method=youtube.videos.list_by_user&dev_id=$dev_id&user=$account");
}

if(preg_match('#<ut_response status="ok">#',$stream))//controle r�ponse fichier xml
	{
//mise en tableau
preg_match_all('#<id>(.*?)</id>#',$stream,$regs);
if(isset($_GET['video_id'])) 
 {$array_id=explode(" ",$video_id);}
else
 {$array_id=$regs[1];}

//info g�n�rale
preg_match_all('#<author>(.*?)</author>#',$stream,$regs);
$array_author=$regs[1];
preg_match_all('#<title>(.*?)</title>#',$stream,$regs);
$array_title=$regs[1];
preg_match_all('#<length_seconds>(.*?)</length_seconds>#',$stream,$regs);
$array_length_seconds=$regs[1];
preg_match_all('#<rating_avg>(.*?)</rating_avg>#',$stream,$regs);
$array_rating_avg=$regs[1];
preg_match_all('#<rating_count>(.*?)</rating_count>#',$stream,$regs);
$array_rating_count=$regs[1];
preg_match_all('#<description>(.*?)</description>#',$stream,$regs);
$array_description=$regs[1];
preg_match_all('#<view_count>(.*?)</view_count>#',$stream,$regs);
$array_view_count=$regs[1];
preg_match_all('#<upload_time>(.*?)</upload_time>#',$stream,$regs);
$array_upload_time=$regs[1];
preg_match_all('#<comment_count>(.*?)</comment_count>#',$stream,$regs);
$array_comment_count=$regs[1];
preg_match_all('#<tags>(.*?)</tags>#',$stream,$regs);
$array_tags=$regs[1];
preg_match_all('#<url>(.*?)</url>#',$stream,$regs);
$array_url=$regs[1];
preg_match_all('#<thumbnail_url>(.*?)</thumbnail_url>#',$stream,$regs);
$array_thumbnail_url=$regs[1];
//info de d�tail
preg_match_all('#<recording_date>(.*?)</recording_date>#',$stream,$regs);
$array_recording_date=$regs[1];
preg_match_all('#<recording_location>(.*?)</recording_location>#',$stream,$regs);
$array_recording_location=$regs[1];
preg_match_all('#<recording_country>(.*?)</recording_country>#',$stream,$regs);
$array_recording_country=$regs[1];
preg_match_all('#<update_time>(.*?)</update_time>#',$stream,$regs);
$array_update_time=$regs[1];
////
preg_match_all('#<comment_list>(.*?)</comment_list>#',$stream,$regs);
$array_comment_list=$regs[1];
$string_comment=implode("_",$array_comment_list);

preg_match_all('#<comment>(.*?)</comment>#',$string_comment,$regs);
$array_comment=$regs[1];

preg_match_all('#<author>(.*?)</author>#',$string_comment,$regs);
$array_comment_author=$regs[1];
preg_match_all('#<text>(.*?)</text>#',$string_comment,$regs);
$array_comment_text=$regs[1];
preg_match_all('#<time>(.*?)</time>#',$string_comment,$regs);
$array_comment_time=$regs[1];

$nb_video=count($array_id);//nombre de video dans le fichier xml
$nb_comment=$array_comment_count[0];//nombre de commentaire

////////////////
if (!isset($_GET['start_round']) || $_GET['start_round'] < 0) 
	{
		$start_round=0;
	} else {
		$start_round=$_GET['start_round'];
	}
if (!isset($_GET['total_found'])) {
		$total_found = $nb_video;
	} else {
		$total_found=$_GET['total_found'];
	}
	if ($start_round + $incrementby < $total_found ) {
		$next_round = $start_round + $incrementby;
	} else {
		$next_round = $total_found;
	}
	if ($start_round == 0) {
		$prev_round = 1;
	} else {
		$prev_round = $start_round + 1;
	}

//mise en forme des dates
if (preg_match('#^\[#',$locale,$regs))
	{
$crit_rech="#\[$language\](.*?)\[/$language\]#";
preg_match($crit_rech,$locale,$regs);
$locale_yt=$regs[1];
	}
else
	{
$locale_yt=$locale;
	};
setlocale (LC_ALL, $locale_yt);
for($i=0; $i<count($array_upload_time) ; $i++) 
		{
$date_1 .=strftime ( "%A %e %B %Y, %R_" ,$array_upload_time[$i]);
$date_2 .=strftime ( "%A %e %B %Y, %R_" ,$array_update_time[$i]);
for($ii=0; $ii<$nb_comment ; $ii++) 
			{
$date_3 .=strftime ( "%m /%d /%y %R_" ,$array_comment_time[$ii]);
			}
		};

$array_upload_time=preg_split ('#_#',$date_1);
$array_update_time=preg_split ('#_#',$date_2);
$array_comment_time=preg_split ('#_#',$date_3);


//construction du bloc d'affichage
for($i=$start_round; $i<$next_round ; $i++)
    {
    if (cur_charset=="utf-8")//mise en forme des dates
		{
		$array_upload_time[$i]=utf8_encode($array_upload_time[$i]);
		$array_update_time[$i]=utf8_encode($array_update_time[$i]);
 		}
    
    $affichage.="<tr><td>
    <span class=\"$class_sty_2\">".video_yt_translate("Auteur :")." </span>".preg_replace($pat,"$rep_account",$array_author[$i]).// remplace le nom du compte Youtube
    "<br/>
    <span class=\"$class_sty_2\">".video_yt_translate("Titre :")." </span>$array_title[$i]<br />
    <span class=\"$class_sty_2\">".video_yt_translate("Dur&#xE9;e :")." </span>$array_length_seconds[$i]<br />
    <span class=\"$class_sty_2\">".video_yt_translate("Moyenne des votes :")." </span>$array_rating_avg[$i]<br />
    <span class=\"$class_sty_2\">".video_yt_translate("Votes :")." </span>$array_rating_count[$i]<br />
    <span class=\"$class_sty_2\">".video_yt_translate("Description :")." </span>$array_description[$i]<br />
    <span class=\"$class_sty_2\">".video_yt_translate("Vu :")." </span>$array_view_count[$i]<br />
    <span class=\"$class_sty_2\">".video_yt_translate("Ajout&#xE9;e le :")." </span>$array_upload_time[$i]<br />
    <span class=\"$class_sty_2\">".video_yt_translate("Commentaire(s) :")." </span>$array_comment_count[$i]<br />
    <span class=\"$class_sty_2\">".video_yt_translate("Mots-clefs :")." </span>$array_tags[$i]<br /><br />
    <img src =\"$array_thumbnail_url[$i]\" title=\"$array_title[$i]\" alt=\" $array_title[$i] : $array_description[$i]\"><br />";
    
    if(!isset($_GET['video_id'])) 
    	{ 
    $affichage.= "<a href=\"modules.php?ModPath=video_yt&ModStart=video_yt&video_id=$array_id[$i]\" title=\"Plus de d&#xE9;tail sur cette vid&#xE9;o\">".video_yt_translate("D&#xE9;tail")."</a><br />";
    	} 
    	else 
    	{ 
    $affichage.="<br /><span class=\"$class_sty_2\">".video_yt_translate("Date :")." </span>$array_update_time[$i]<br />
    <span class=\"$class_sty_2\">".video_yt_translate("Pays :")." </span>$array_recording_country[$i]<br />
    <span class=\"$class_sty_2\">".video_yt_translate("Localisation :")." </span>$array_recording_location[$i]<br />
    ";
        if ($nb_comment > 0) // si il y a des commentaires...
    		{
    $affichage.="<br /><span class=\"$class_sty_2\">".video_yt_translate("Commentaire(s) :")." </span><br />";
			for ( $ii = 0; $ii < $nb_comment; $ii++ )
				{
				if (cur_charset=="utf-8")//mise en forme des dates
		{
		$array_comment_time[$ii]=utf8_encode($array_comment_time[$ii]);
 		}
				
  $affichage.="$array_comment_time[$ii] <span class=\"$class_sty_2\"> $array_comment_author[$ii] : </span><br />
    <span class=\"$class_sty_3\"> $array_comment_text[$ii]</span><br />";  
				}
    		}
        }
   
  $affichage.=" 
   <br /></td><td><object width=\"600\" height=\"400\"><param name=\"movie\" value=\"http://www.youtube.com/v/$array_id[$i]\"></param><param name=\"wmode\" value=\"transparent\"></param><embed src=\"http://www.youtube.com/v/$array_id[$i]\" type=\"application/x-shockwave-flash\" wmode=\"transparent\" width=\"$video_width\" height=\"$video_height\"></embed></object><br /></td></tr> ";
    };   
    
//Construction du bloc navigation
if ($start_round != 0) 
   {
	$prev_round = $start_round - $incrementby;
	$nav_block .=  "<a class=\"w\" href=\"modules.php?ModPath=video_yt&ModStart=video_yt&start_round=0&total_found=$total_found\">[".video_yt_translate("Premi&#xE8;res")."]</a>";
     $nav_block .= " <a class=\"w\"  href=\"modules.php?ModPath=video_yt&ModStart=video_yt&start_round=$prev_round&total_found=$total_found\">[".video_yt_translate("Pr&#xE9;c&#xE9;dentes")."]</a>";
   }
else
   {
   $nav_block .= "".video_yt_translate("Premi&#xE8;res")." | ".video_yt_translate("Pr&#xE9;c&#xE9;dentes")."";
	}
if ($start_round == 0) 
   { $begin_round = 1; } 
else 
   { $begin_round = $start_round; };
	$nav_block .= "	&nbsp;&nbsp; ".video_yt_translate("Fiches")." $begin_round ".video_yt_translate("&#xE0;")." $next_round (".video_yt_translate("total")." : ". $total_found . ")&nbsp;&nbsp;";

if ($start_round +$incrementby< $total_found) {
    $next_page = $start_round +$incrementby;
    $nav_block .= " <a class=\"e\" href=\"modules.php?ModPath=video_yt&ModStart=video_yt&start_round=$next_page&total_found=$total_found\">[".video_yt_translate("Suivantes")."]</a>";
    $last_records = $total_found-$incrementby;
    $nav_block .= " <a class=\"e\" href=\"modules.php?ModPath=video_yt&ModStart=video_yt&start_round=$last_records&total_found=$total_found\">[".video_yt_translate("Derni&#xE8;res")."]</a>";
}else {
		$nav_block .= " ".video_yt_translate("Suivantes")." | ".video_yt_translate("Derni&#xE8;res")."";
	}
 if (cur_charset!="utf-8")
 $affichage = utf8_decode($affichage);
//Affichage page       
echo "<div class=\"$class_sty_1\">".video_yt_translate("Vid&#xE9;oth&#xE8;que")." [$nb_video]</div><br /><hr />
<table border=\"1\">
$affichage
</table>";
if(!isset($_GET['video_id'])) 
{echo"<br />$nav_block";}
else
{echo"<br /><a href=\"modules.php?ModPath=video_yt&ModStart=video_yt\">".video_yt_translate("Vid&#xE9;oth&#xE8;que")."</a><hr />";}
	}
	else
	{
echo "<div class=\"$class_sty_1\">".video_yt_translate("Vid&#xE9;oth&#xE8;que")."</div><br /><hr />".video_yt_translate("R&#xE9;ponse incorrecte du fichier xml de Youtube.")."";
	};
include ('footer.php');
?>