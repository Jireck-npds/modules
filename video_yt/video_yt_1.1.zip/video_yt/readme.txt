﻿###################################################################################
##
## Nom:  video_yt
## Version:  1.1
## Date: 20/02/08
## Auteur:  Jpb 
## 
## Description :
## Module qui permet d'afficher dans NPDS les vidéos stockées sur Youtube 
## 
## Niveau d'installation : simple
## Temps d'installation : 1 minute
## Fichiers a Èditer :  0
##
#######################################################################################
##
## ** INSTALLATION : **
## 1. Décompresser l'archive.
## 2. Copier le contenu de l'archive dossier video_yt dans le dossier modules
## 3. Rendez-vous dans la section "Gestion des modules" dans l'administration et cliquez sur "Installer le module" en face de "video_yt" et suivez la procédure.
##
##
#######################################################################################
##
## Nom:  video_yt
## Version:  1.1
## Date:  20/02/08
## Auteur: Jpb 
##
#######################################################################################