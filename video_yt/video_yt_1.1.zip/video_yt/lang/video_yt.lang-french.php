<?
/************************************************************************/
/* NPDS : Net Portal Dynamic System                                     */
/* ===========================                                          */
/*                                                                      */
/* video_yt Language File Copyright (c) 2007 by jpb                     */
/*                                                                      */
/************************************************************************/

function video_yt_translate($phrase) {
   return $phrase;
}
?>