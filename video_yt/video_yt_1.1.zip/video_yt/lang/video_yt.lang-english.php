<?PHP
/************************************************************************/
/* NPDS V : Net Portal Dynamic System .                                 */
/* ===========================                                          */
/*                                                                      */
/* Original Copyright (c) 2001 by Francisco Burzi (fburzi@ncc.org.ve)   */
/* http://phpnuke.org                                                   */
/*                                                                      */
/* This version name NPDS Copyright (c) 2001-2007 by Philippe Brunier   */
/*                                                                      */
/*                                                                      */
/* english video_yt Language file 2007 by jpb                           */
/* Translated by : Jean Pierre Barbary                                  */
/*                                                                      */
/************************************************************************/


function video_yt_translate($phrase) {
 switch($phrase) {
  
case "Vid&#xE9;os": $tmp="Videos"; break;
case "Vid&#xE9;oth&#xE8;que": $tmp="Videos"; break;
case "Auteur :": $tmp="Author:"; break;
case "Vu :": $tmp="Views:"; break;
case "Titre :": $tmp="Title:"; break;
case "Commentaire(s) :": $tmp="Comment(s):"; break;
case "Dur&#xE9;e :": $tmp="Length :"; break;
case "Votes :": $tmp="Ratings :"; break;
case "Moyenne des votes :": $tmp="Ratings average:"; break;
case "Description :": $tmp="Description :"; break;
case "Mots-clefs :": $tmp="Tags:"; break;
case "R&#xE9;ponse incorrecte du fichier xml de Youtube.": $tmp="The xml file answer send by youtube seems to be false...:"; break;
case "Mots-clefs :": $tmp="Tags:"; break;
case "Ajout&#xE9;e le :": $tmp="Added:"; break;
case "Localisation :": $tmp="Location:"; break;
case "D&#xE9;tail :": $tmp="Detail:"; break;
case "Voir": $tmp="Watch"; break;
case "Plus de d&#xE9;tail sur cette vid&#xE9;o": $tmp="More details about this video"; break;


case "Premi&#xE8;res": $tmp="First"; break;
case "Pr&#xE9;c&#xE9;dentes": $tmp="Previous page"; break;
case "&#xE0;": $tmp="to"; break;
case "Fiches": $tmp="Records"; break;
case "total": $tmp="total"; break;
case "Suivantes": $tmp="Next page"; break;
case "Derni&#xE8;res": $tmp="Last"; break;

case "Pays :": $tmp="Country:"; break;
case "Localisation :": $tmp="Location:"; break;

case "Configuration du module vid&#xE9;o": $tmp="Module video configuration"; break;
case "requis": $tmp="required"; break;
case "Votre ID developpeur youtube": $tmp="Your Youtube developer ID"; break;
case "Votre username youtube": $tmp="Your Youtube username"; break;
case "Largeur de la vid&#xE9;o": $tmp="Width of the video:"; break;
case "Hauteur de la vid&#xE9;o": $tmp="Hight of the video:"; break;
case "Largeur de la vid&#xE9;o dans le bloc": $tmp="Width of the video in block:"; break;
case "Hauteur de la vid&#xE9;o dans le bloc": $tmp="Hight of the video in block:"; break;
case "Nombre de vid&#xE9;o par page": $tmp="Number of video per page"; break;
case "Classe de style titre": $tmp="Class of style title"; break;
case "Classe de style sous-titre": $tmp="Class of style sub_title:"; break;
case "Classe de style commentaire": $tmp="Class of style comment"; break;
case "Sauver": $tmp="Save"; break;

case "Latitude :": $tmp="Latitude:"; break;
case "Longitude :": $tmp="Longitude:"; break;
case "Voir le profil @ YouTube.com": $tmp="Show user profil @ YouTube.com"; break;
   default: $tmp = "Need to be translated <b>[** $phrase **]</b>"; break;
 }
 if (cur_charset=="utf-8") {
    return utf8_encode($tmp);
 } else {
    return ($tmp);
 }
}
?>