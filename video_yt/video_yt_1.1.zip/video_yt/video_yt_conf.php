<?php 
/************************************************************************/
/* NPDS V : Net Portal Dynamic System .                                 */
/* ===========================                                          */
/*                                                                      */
/* This version name NPDS Copyright (c) 2001-2007 by Philippe Brunier   */
/*                                                                      */
/* Module video_yt conf file 2007 by jpb                                */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/
// param&#xE8;tres Youtube 
$dev_id = "HSkI3UPljNU"; // obtenez votre DEV_ID at http://www.youtube.com/signup?next=my_profile_dev 
$account = "jipexu";// YouTube Username 
// mise en forme 
$rep_account = "Jean Pierre Barbary";// youtube name 
$incrementby = "3";// nombre de vid&#xE9;os par page dans vid&#xE9;oth&#xE8;que 
$video_width = "425"; //largeur de l'objet 
$video_height = "350"; //hauteur de l'objet 
$bloc_width = "200"; //largeur de l'objet dans le bloc
$bloc_height = "150"; //hauteur de l'objet dans le bloc 
$class_sty_1 = "titrgkc"; //titre de la page 
$class_sty_2 = "TITBOXCONT"; //sous-titre de la page 
$class_sty_3 = ""; //commentaire 
?>